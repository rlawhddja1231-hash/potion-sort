# 물약 나누기 (Potion Sort)

같은 색 물약끼리 한 병에 모으는 퍼즐 게임. 안드로이드 앱(Capacitor) + 구글 애드몹 광고.

- `www/index.html` — 게임 전체 (광고 ID는 맨 위 ADS 부분)
- `android/` — 안드로이드 앱 프로젝트
- `.github/workflows/build.yml` — 깃허브에 올리면 시험용 APK를 자동으로 만들어 줌
- `docs/privacy.html` — 개인정보처리방침 (플레이스토어 제출용, 깃허브 페이지로 공개)
- `store/icon-512.png` — 플레이스토어 아이콘

## 출시 전에 꼭 바꿀 것
1. `www/index.html`의 ADS 광고 ID 3개 → 내 애드몹 광고 ID
2. `android/app/src/main/AndroidManifest.xml`의 APPLICATION_ID → 내 애드몹 앱 ID
3. `docs/privacy.html`의 [연락 이메일]
