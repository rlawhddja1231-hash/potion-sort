from PIL import Image, ImageDraw, ImageFilter
import os
BG=(34,27,52); S=1024
def bottle(size, scale=1.0, bg=None):
    im=Image.new('RGBA',(size,size),bg or (0,0,0,0)); d=ImageDraw.Draw(im)
    c=size/2; w=size*0.40*scale; h=size*0.60*scale
    top=c-h*0.45; bot=c+h*0.55
    # glow
    if bg:
        g=Image.new('RGBA',(size,size),(0,0,0,0)); gd=ImageDraw.Draw(g)
        gd.ellipse([c-w*1.1,c-w*0.9,c+w*1.1,c+w*1.3],fill=(233,185,73,90))
        im.alpha_composite(g.filter(ImageFilter.GaussianBlur(size*0.08)))
        d=ImageDraw.Draw(im)
    nw=w*0.42; nh=h*0.16
    body=[c-w/2,top+nh,c+w/2,bot]
    r=w*0.32
    # liquid layers clipped by body mask
    mask=Image.new('L',(size,size),0); md=ImageDraw.Draw(mask)
    md.rounded_rectangle(body,radius=r,fill=255)
    liq=Image.new('RGBA',(size,size),(0,0,0,0)); ld=ImageDraw.Draw(liq)
    cols=[(229,72,77),(62,142,247),(70,195,123),(245,197,66)]
    bh=(bot-(top+nh))
    for i,col in enumerate(cols):
        y1=bot-bh*(i+1)/4.6; y0=bot-bh*i/4.6
        ld.rectangle([body[0],y1,body[2],y0],fill=col+(255,))
    im.paste(liq,(0,0),Image.composite(liq,Image.new('RGBA',(size,size)),mask).split()[3])
    hl=Image.new('RGBA',(size,size),(0,0,0,0)); ImageDraw.Draw(hl).rounded_rectangle([body[0]+w*0.13,top+nh+bh*0.15,body[0]+w*0.23,bot-bh*0.15],radius=w*0.05,fill=(255,255,255,90)); im.alpha_composite(hl)
    d=ImageDraw.Draw(im)
    lw=max(2,int(size*0.018))
    d.rounded_rectangle(body,radius=r,outline=(235,240,255,255),width=lw)
    d.rectangle([c-nw/2,top,c+nw/2,top+nh+lw],outline=(235,240,255,255),width=lw)
    d.rounded_rectangle([c-nw*0.62,top-nh*0.55,c+nw*0.62,top+nh*0.25],radius=size*0.015,fill=(156,107,63,255))
    return im
full=bottle(S,1.0,BG+(255,))
res='android/app/src/main/res'
sizes={'mdpi':48,'hdpi':72,'xhdpi':96,'xxhdpi':144,'xxxhdpi':192}
fg_sizes={'mdpi':108,'hdpi':162,'xhdpi':216,'xxhdpi':324,'xxxhdpi':432}
for k,v in sizes.items():
    sq=full.resize((v,v),Image.LANCZOS); sq.save(f'{res}/mipmap-{k}/ic_launcher.png')
    m=Image.new('L',(v,v),0); ImageDraw.Draw(m).ellipse([0,0,v-1,v-1],fill=255)
    rd=Image.new('RGBA',(v,v),(0,0,0,0)); rd.paste(sq,(0,0),m); rd.save(f'{res}/mipmap-{k}/ic_launcher_round.png')
fg=bottle(S,0.62)
for k,v in fg_sizes.items(): fg.resize((v,v),Image.LANCZOS).save(f'{res}/mipmap-{k}/ic_launcher_foreground.png')
full.resize((512,512),Image.LANCZOS).convert('RGB').save('store/icon-512.png')
print('ok')
