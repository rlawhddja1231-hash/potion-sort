package com.mulyak.potionsort;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
