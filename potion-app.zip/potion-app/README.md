# 물약 나누기 (Potion Sort)

같은 색 물약끼리 한 병에 모으는 퍼즐 게임. 안드로이드 앱(Capacitor) + 구글 애드몹 광고.

- `www/index.html` — 게임 전체 (광고 ID는 맨 위 ADS 부분)
- `android/` — 안드로이드 앱 프로젝트
- `.github/workflows/build.yml` — 깃허브에 올리면 시험용 APK를 자동으로 만들어 줌
- `docs/privacy.html` — 개인정보처리방침 (플레이스토어 제출용, 깃허브 페이지로 공개)
- `store/icon-512.png` — 플레이스토어 아이콘

## 애드몹 번호 (물약 나누기)
- 앱 ID: ca-app-pub-3635656609385763~1439513596 (AndroidManifest.xml에 넣어 둠)
- 띠 광고 bottom_banner: ca-app-pub-3635656609385763/7673749451
- 전면 광고 level_clear_interstitial: ca-app-pub-3635656609385763/5047586111
- 보상 광고 hint_rewarded: ca-app-pub-3635656609385763/2421422771

## 출시 전에 꼭 할 것
1. `www/index.html`의 `TEST_MODE`를 false로 (시험 중엔 true — 내 광고를 내가 보면 계정 정지 위험)

